import React from 'react'

function Unknownuser() {
    return (
        <div>
            <h1>Welcome user!</h1>

            <form>
                <lable>Name</lable>
                <input type='text'></input>
                <br></br>
                <lable>email</lable>
                <input type='email'></input>
                <br></br>
                <lable>password</lable>
                <input type='password'></input>
            </form>
        </div>
    )
}

export default Unknownuser
