import React from 'react'

function Ecomlogin() {
    return (
        <h1>LOGIN!</h1>
    )
}

export default Ecomlogin
