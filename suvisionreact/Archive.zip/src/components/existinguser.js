import React, { useContext } from 'react'

function Existinguser() {
    
    return (

        <>
         <h1>Welcome </h1>

         <div>
            home page
         </div>
        </>
       

        
    )
}

export default Existinguser
