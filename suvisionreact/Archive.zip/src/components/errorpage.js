import React from 'react'

function Errorpage() {
    return (
        <h1>ERROR 404 !
            <h5>The page your are looking for doesnot exist!</h5>
        </h1>
    )
}

export default Errorpage
